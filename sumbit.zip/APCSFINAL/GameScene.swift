//
//  GameScene.swift
//  APCSFINAL
//
//  Created by RishavM on 28/05/2019.
//  Copyright © 2016 Rishav Mukherjee. All rights reserved.
//


//Going to try to explain as much as I can

//FULL DISCLOSURE
//This is my attempt in re-creating flappy bird from memory, applying what I had learned after going through the tutorial multiple times. Whenever I forgot what I was supposed to do or got stuck I consulted the tutorial, but very little. A polished flappy bird game would not be representative of my current skill level, so I tried to do as much as I could for what I knew.

import SpriteKit

enum GameState {
	case showingBackground //Enum that links to the switch in the didMove class that details the three main
	case playing//events
	case dead
}

class GameScene: SKScene, SKPhysicsContactDelegate {
	var player: SKSpriteNode! //Initializing the main variables
	var background: SKSpriteNode!
	var gameOver: SKSpriteNode!//NOT USED
	var gameState = GameState.showingBackground //sets the gamestate of the GameScene.sks to the showingBackground case, which activates the player node and also leads to the .playing. case


	var scoreLabel: SKLabelNode! //Also not used

	

    override func didMove(to view: SKView) {
        generateBackground() //Calls the functions that start the game
		createPlayer() //Creates the player, with the physics assigned to it, in the sks
        
		
		

		physicsWorld.gravity = CGVector(dx: 0.0, dy: -5.0) //Makes the gravity in the scene a little "heavier"
		physicsWorld.contactDelegate = self//on the Y axis.
        //Calls the physicsContactDelegate protocol, which sets up collision between nodes
		
    }
    
    

	override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
		switch gameState { //Switch that contacts the enum at the top that details the 3 main events of the game
		case .showingBackground:
			gameState = .playing //calls the second case of .playing, which initializes the player's velocity
                                            //[unowned self] means you want to reference the class but not own it, and I'm not 100% sure what that means...
			let activatePlayer = SKAction.run { [unowned self] in
				self.player.physicsBody?.isDynamic = true//Allows the player node to be affected by other nodes dymaically, or on the fly, including gravity.
				self.startPipes() //Calls the startPipes class, which basically loops the pipe creation and pipe deletion, which gives an illusion of scrolling
			}

			let sequence = SKAction.sequence([ activatePlayer]) //Calls the activatePlayer variable in a sequence,  which sets the player's physics to dynamic, allowing is to be affected by the gravity of the scene, and fall. Once the player touches the phone, the touches began class is called.
			background.run(sequence) //Runs the above code, thus ending the showbackground case and officially "beggining" the game

		case .playing: //Second case that is called in the .showingBackground. case
			player.physicsBody?.velocity = CGVector(dx: 0, dy: 0) //Sets the player to be still
			player.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 20))//Gives the player an impulse or a "push" in the y axis, instead of letting the player be affected by normal gravity.

		case .dead: //Not implemented properly, didn't have time
			let scene = GameScene(fileNamed: "GameScene")!
			let transition = SKTransition.moveIn(with: SKTransitionDirection.right, duration: 1)
			self.view?.presentScene(scene, transition: transition)
		}
	}

    func createPlayer() { //Called in the didMove class, generates the player, player will now be referred rto as bird
		let playerTexture = SKTexture(imageNamed: "player-1")//sets the bird's texture, I used ansh's face for this
		player = SKSpriteNode(texture: playerTexture)//Applies the texture
		player.zPosition = 10//Sets the original position on the Z axis, which doesn't really apply here, but still needed for the creation of the player.
		player.position = CGPoint(x: frame.width / 6, y: frame.height * 0.75) //Puts the bird at the top right of the screen
        
        

		addChild(player) //Adds the player to the game

		player.physicsBody = SKPhysicsBody(texture: playerTexture, size: playerTexture.size()) //Sets the coliztion size, which should be scaled to the outline of the .png, which is what the playerTexture.size references
        
        
        //Three lines of code below are necesseray to ensure the bird collides properly with the pipes
		player.physicsBody!.contactTestBitMask = player.physicsBody!.collisionBitMask
		player.physicsBody?.isDynamic = false

		player.physicsBody?.collisionBitMask = 0

	}

	

	

	

	

	func generateBackground() {
        //Same as the player, sets the image for the background.
		background = SKSpriteNode(imageNamed: "player-1")
        //Same as the player, positions the background to the middle of the iphone screen
		background.position = CGPoint(x: frame.midX, y: frame.midY)
		addChild(background)
        

		gameOver = SKSpriteNode(imageNamed: "gameover")//Also not implemented correctly, I don't know what I did wrong, the game is supposed to end and display a picture whne the bird goes off screen
		gameOver.position = CGPoint(x: frame.midX, y: frame.midY)
		gameOver.alpha = 0
		addChild(gameOver)
	}
	func createPipes() {
		//Setting texture
		let pipeTexture = SKTexture(imageNamed: "Pip")
        
        //Creating collision constant
        //Ok looking back on this I realize I don't have time to create proper collision
        let topPipe = SKSpriteNode(texture: pipeTexture)

		
		topPipe.physicsBody?.isDynamic = false
		
		topPipe.xScale = -1.0
        topPipe.physicsBody = SKPhysicsBody(texture: pipeTexture, size: pipeTexture.size())//Sets the pipe as a colidable object
        let bottomPipe = SKSpriteNode(texture: pipeTexture) //Sets the pipe as a colidable object
        bottomPipe.physicsBody = SKPhysicsBody(texture: pipeTexture, size: pipeTexture.size()) //Applies texture to the pipe
		
		
		bottomPipe.physicsBody?.isDynamic = false
        
        //Setting the start of the pipes to the start of the iphone frame
		topPipe.zPosition = -20
		bottomPipe.zPosition = -20
		addChild(topPipe)
		addChild(bottomPipe)


		
		let TopOfPipe = frame.width + topPipe.frame.width

		let max = CGFloat(frame.height / 3)
		let BottomOfPipe = CGFloat.random(in: -50...max) //Supposed to randomize the height that the pipes reach down to and the bottom pipe reaches up to, that's how I did it in the previous project, how ever I think I messed up on the initialization of the pipes, because they're just sticking together and not separating to random heights.
		let width: CGFloat = 70

		topPipe.position = CGPoint(x: TopOfPipe, y: BottomOfPipe + topPipe.size.height + width)
		bottomPipe.position = CGPoint(x: TopOfPipe, y: BottomOfPipe - width)
		let endPosition = frame.width + (topPipe.frame.width * 2)
		let moveAction = SKAction.moveBy(x: -endPosition, y: 0, duration: 6.2) //Moves the pipe, which is done frame by frame, along the ground
		let moveSequence = SKAction.sequence([moveAction, SKAction.removeFromParent()])
		topPipe.run(moveSequence)
		bottomPipe.run(moveSequence)
		
	}

	func startPipes() {
		let create = SKAction.run { [unowned self] in
			self.createPipes()
		}
        //Begins the movement of the pipe, continuously calls the createPipes method, which in turn has the Action and moveSequence that creates the image of scrolling.
        
        //Also handles the timing of the spawning of the pipes.
		let wait = SKAction.wait(forDuration: 3)
		let sequence = SKAction.sequence([create, wait])
		let repeatForever = SKAction.repeatForever(sequence)
		run(repeatForever)
	}

    
    
    //function that makes sure the bird's physics are correct, returns if they are.
	override func update(_ currentTime: TimeInterval) {
        
		guard player != nil else { return }

		let value = player.physicsBody!.velocity.dy * 0.001
		let rotate = SKAction.rotate(toAngle: value, duration: 0.1)

		player.run(rotate)
	}

			
		}



